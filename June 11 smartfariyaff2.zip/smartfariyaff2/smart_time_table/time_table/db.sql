-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 05, 2018 at 05:47 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `interactivetimetable`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `classId` int(11) NOT NULL,
  `className` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`ID`, `classId`, `className`) VALUES
(1, 1, 'x'),
(2, 2, 'IX'),
(3, 3, 'VIII'),
(4, 4, 'VII'),
(8, 6, 'V');

-- --------------------------------------------------------

--
-- Table structure for table `config_timetable`
--

CREATE TABLE IF NOT EXISTS `config_timetable` (
  `lecturesPerDay` int(11) NOT NULL,
  `startTime` varchar(20) NOT NULL,
  `endTime` varchar(20) NOT NULL,
  `breakAfter` int(20) NOT NULL,
  `breakDuration` int(20) NOT NULL,
  `lecturesDuration` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config_timetable`
--

INSERT INTO `config_timetable` (`lecturesPerDay`, `startTime`, `endTime`, `breakAfter`, `breakDuration`, `lecturesDuration`) VALUES
(6, '08:00', ' 01:00', 3, 30, ' 45,45,45,45,45,45');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `subjectId` int(11) NOT NULL,
  `subjectName` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`ID`, `subjectId`, `subjectName`) VALUES
(2, 1, 'COMPUTER'),
(4, 2, 'BIOLOGY'),
(5, 3, 'CHEMISTRY'),
(6, 4, 'PHYSICS'),
(11, 5, 'ISLAMYAT');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `tname` varchar(25) NOT NULL,
  `tfname` varchar(25) NOT NULL,
  `tqualification` varchar(20) NOT NULL,
  `tsubject` varchar(20) NOT NULL,
  `tphone` int(12) NOT NULL,
  `taddress` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `email` varchar(25) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `tname`, `tfname`, `tqualification`, `tsubject`, `tphone`, `taddress`, `gender`, `email`) VALUES
(1, 'Abbas muhammad', '', 'mphil(computer)', 'computer', 2147483647, 'depalpur', 'male', ''),
(2, 'Azeem Rehan', '', 'Mphil(computer)', 'computer', 333, 'depalpur', 'male', ''),
(3, 'Shah hussain', '', 'MS(math)', 'Math', 123345678, 'okara', 'male', ''),
(4, 'zeeshan', 'Ahmad', 'Ms(chemisrty)', 'chemistry', 12345678, 'okara', 'male', ''),
(5, 'Malik Masood', '', 'mphil(compute graphi', 'computer', 2147483647, 'lahore', 'male', ''),
(6, 'M.Arsalan ', 'Ahmad', 'Mphil(computer)', 'computer', 2147483647, 'depalpur', 'male', ''),
(13, 'Sadia Haider', 'Ghulam Haider', 'Bs botny', 'Biology', 333, 'okara', 'Femal', 'iqrakhanshahzad');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE IF NOT EXISTS `timetable` (
  `classId` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `teacherName` varchar(20) NOT NULL,
  `subjectName` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`classId`, `period`, `teacherName`, `subjectName`) VALUES
(3, 1, 'Shah hussain', 'chemistry'),
(3, 3, 'Abbas muhammad', 'computer'),
(1, 4, 'Azeem Rehan', 'biology'),
(9, 4, 'Abbas muhammad', 'Islamyat'),
(1, 1, 'Abbas muhammad', 'computer'),
(1, 2, 'M.Arsalan', 'CHEMISTRY'),
(4, 4, 'Abbas muhammad', 'COMPUTER'),
(6, 3, 'Asma saleem', 'BIOLOGY'),
(2, 2, 'zee', 'BIOLOGY');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(30) NOT NULL,
  `userEmail` varchar(60) NOT NULL,
  `userPass` varchar(255) NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `userEmail` (`userEmail`),
  UNIQUE KEY `userEmail_2` (`userEmail`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`) VALUES
(1, 'maya', 'umairahansaleem@gmail.com', 'b88820297dbee1ad816be143c7e462ef0f9a36475fc7cf5556a487c6e089bed1'),
(2, 'sana', 'umairahansaleem@gmail.com', 'f707fdda7c874ff49ebfb2c88a2860c5ff4ce3d94a21efb76566ad0f92c9ad57'),
(3, 'humaira', 'umairahansaleem@gmail.com', '9260eeafd5b61f8e4b1b8e61112d1dd20deff3488438430d6df930fba769deb3'),
(4, 'umaira', 'umaira992@gmail.con', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(5, 'Muhammad ali', 'abc@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92');
