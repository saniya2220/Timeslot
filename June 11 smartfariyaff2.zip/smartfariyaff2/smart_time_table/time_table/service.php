<?php
ob_start();
session_start();
require_once 'dbconnect.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>

    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->
</head>
<body class="size-1140">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a href="https://www.facebook.com/profile.php?id=100014911838004"><i class="icon-facebook_circle"></i></a>
					 <a><i class="icon-google_plus_circle"></i></a> 
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>Services</strong></p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                    <li class="active-item"><a href="front.php">Home</a></li>

                      <li><a href="ttview.php">Time Table</a></li> 
                      
                      <li><a href="about.php">About Us</a></li>
                      
                      <li><a href="service.php">Services</a></li>
                      <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    

</header>
<section>
    <!-- Teacher's view -->
    <br><br><br><br><br>
    <div id="services">
        <div class="line">
            <h2 class="section-title">Services</h2>
<br>
            <div class="margin">
                <div class="s-12 m-6 l-4 margin-bottom">
                    <i class="icon-vector"></i>
                    <div class="service-text">
                        <h3>We create</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                    </div>
                </div>
                <div class="s-12 m-6 l-4 margin-bottom">
                    <i class="icon-eye"></i>
                    <div class="service-text">
                        <h3>We look to the future</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                    </div>
                </div>
                <div class="s-12 m-12 l-4 margin-bottom">
                    <i class="icon-random"></i>
                    <div class="service-text">
                        <h3>We find a solution</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MAP -->
    
</section>
<!-- FOOTER -->
<footer>
    <div class="line">
        <div class="s-12 l-6">
            <p>All copyrights are reserved (2018) </p>
            <p> All images are for the need of project. Don't copy any image.</p>
        </div>
        <div class="s-12 l-6">
            <a class="right" href="http://www.iqrakhan/sites.com" title="Responsee - lightweight responsive framework">Design and coding<br> by Responsee Team</a>
        </div>
    </div>
</footer>
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>
<?php ob_end_flush(); ?>