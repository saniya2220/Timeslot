<?php

require_once 'dbconnect.php';
include_once 'connection.php';
if(isset($_POST['submit']));
if(isset($_POST)& !empty($_POST))
{

$period=$_POST['period_id'];
$classid=$_POST['class_id'];
}

$sq="delete from timetable WHERE period='$period' AND classId='$classid'";

if($connection->query($sq)==TRUE){
	print '<script> alert("The table Data Has been Succesfuly Deleted");</script>';
	header("Location: testtable1.php");

}
else{
	
echo"There is an Error".$sq."<br>".$connection->error;
}

?>
