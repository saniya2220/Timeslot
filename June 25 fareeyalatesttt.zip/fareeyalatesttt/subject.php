<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
@$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    
    <?php include 'link.php'; ?>

    <!----  links about main content      ---->

    
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
        ============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
        ============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- educate icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
        ============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
        ============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
        
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<?php include 'connection.php'; ?>
  <?php include 'includes/side_bar.php'; ?>
  
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.php"><img src="" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
         <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                    <i class="educate-icon educate-nav"></i>
                                                </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                                <li class="nav-item"><a href="#" class="nav-link">Dashboard</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                       <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">  
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                            <img src="img/product/pro4.jpg" alt="" />
                                                            <span class="admin-name">Administrator</span>
                                                            <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                        </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-settings author-log-ic"></span>Settings</a>
                                                        </li>
                                                        <li><a href="logout.php"><span class="edu-icon edu-locked author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="index.php">Home <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="index.php">Dashboard </a></li>
                                               
                                            </ul>
                                        </li>
										   
                                      <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="time_table.php">Time Table <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li> 
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="teacher.php">Teachers <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="subject.php">Subjects <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="class.php">Classes<span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
				                       <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="semester.php">Semesters <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="lecture.php">Lectures <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="day.php">Days  <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="user.php">Users <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                        

                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->

        </div>
        <br>
        <br>
        <br>
              <!-- Static Table Start -->
        <div class="static-table-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list">
                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1>Add Subjects</h1>
                                </div>
                            </div>
                              <!-- Button to Open the Modal -->
                            
                             <br>
                            <div class="sparkline8-graph">
                                <div class="static-table-list">
                                    <div align="center"> <a class="btn btn-info btn-primary" href="subjectinput.php" style="color: #ffff; background-color: #002e63; border-color:#002e63;" role="button">Add New Subject</a></div>
                                    <br>





                       

                        

<table class="table" id="table">
<thead>

    <th>Subject ID</th>
    <th> Subject Name</th>
    <th>Update</th> 
    <th>Delete</th>
    </thead>
<?php 

//$sql2="SELECT * FROM subjects";
$res=mysqli_query($con, "SELECT * FROM subjects");
while($row=mysqli_fetch_array($res))
{
	@$id=$row['subjectId'];
	@$sub=$row['subjectName'];
	
	
	
	
?>	
 <tbody>
<tr class="alt">
<td><?php echo $id  ?></td>
	<td><?php echo $sub?></td>
	
	
	
	<td><a href="subjectupdate.php?id=<?php echo $id ?> "><button type=button style="color: white; background-color: #1E90FF; border-color:#1E90FF; ">Update</button> </a></td>
	<td><a href="subjectdelete.php?id=<?php echo $id ?> "><button type=button style="color: white; background-color: red; border-color:red;" >Delete</button> </a></td>
	</tr>
</tbody>
<?php }?>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


                        
                  

                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
</div>  <!-- WRAPPER END -->



                        
 
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/morrisjs/raphael-min.js"></script>
    <script src="js/morrisjs/morris.js"></script>
    <script src="js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="js/calendar/moment.min.js"></script>
    <script src="js/calendar/fullcalendar.min.js"></script>
    <script src="js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
    
    

</body>
</html>
<?php ob_end_flush(); ?>