<?php
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'interactivetimetable');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
if(isset($_POST)& !empty($_POST)){
$name=$_POST['name'];
$fname=$_POST['fname'];
$qual=$_POST['qual'];
$sub=$_POST['subject'];
$phone=$_POST['phone'];
$add=$_POST['address'];

$sql="INSERT INTO teacher(tname,tfname,tqualification,tsubject,tphone,tAddress)
VALUES('$name','$fname','$qual','$sub','$phone','$add')";
if($connection->query($sql)==TRUE){
	print '<script> alert("The Student Data Has been Succesfuly Uploads");</script>';
}
else{
	
echo"There is an Error".$sql."<br>".$connection->error;
}
}
?>

		