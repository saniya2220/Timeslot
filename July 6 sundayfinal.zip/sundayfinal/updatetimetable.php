<?php
require_once 'dbconnect.php';
include_once 'connection.php';
if(isset($_POST['submit']));
if(isset($_POST)& !empty($_POST))
{

$teacher=$_POST['teacher'];
$subject=$_POST['subject'];
$period=$_POST['period'];
$dayid=$_POST['dayid'];
}
$selectQuery="select * from timetable WHERE period=$period && dayid= $dayid";
$result=$connection->query($selectQuery);
print_r($result);
if(mysqli_num_rows($result)==0){
$insertQuery="INSERT INTO timetable(dayid,period,teacherName,subjectName)
VALUES('$dayid','$period','$teacher','$subject')";

if($connection->query($insertQuery)==TRUE){
	print '<script> alert("The table Data Has been Succesfuly Uploads");</script>';
	header("Location: testtable1.php");

}
else{
	
echo"There is an Error".$insertQuery."<br>".$connection->error;
}
}
else{
$sq = "UPDATE timetable SET  subjectName= '$subject', teacherName='$teacher'  WHERE period='$period' && dayid= '$dayid'";

if($connection->query($sq)==TRUE){
	print '<script> alert("The table Data Has been Succesfuly Updated");</script>';
	header("Location: testtable1.php");

}
else{
	
echo"There is an Error".$sq."<br>".$connection->error;
}
}
?>
