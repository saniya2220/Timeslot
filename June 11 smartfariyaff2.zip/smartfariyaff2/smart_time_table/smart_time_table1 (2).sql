-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2021 at 09:50 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_time_table1`
--

-- --------------------------------------------------------

--
-- Table structure for table `celltype`
--

CREATE TABLE `celltype` (
  `rowid` int(11) NOT NULL,
  `columid` int(11) NOT NULL,
  `celltype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `classId` int(11) NOT NULL,
  `className` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`classId`, `className`) VALUES
(4, 'X'),
(5, 'IX'),
(6, 'VIII'),
(7, 'VII'),
(12, 'VI');

-- --------------------------------------------------------

--
-- Table structure for table `config_timetable`
--

CREATE TABLE `config_timetable` (
  `lecturesPerDay` int(11) NOT NULL,
  `startTime` varchar(255) NOT NULL,
  `endTime` varchar(255) NOT NULL,
  `breakAfter` int(255) NOT NULL,
  `breakDuration` int(255) NOT NULL,
  `lecturesDuration` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `config_timetable`
--

INSERT INTO `config_timetable` (`lecturesPerDay`, `startTime`, `endTime`, `breakAfter`, `breakDuration`, `lecturesDuration`) VALUES
(3, '11:30', ' 1:30', 12, 15, ' 56');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `student_id` int(100) NOT NULL,
  `teacher_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `student_id`, `teacher_id`) VALUES
(2, 4, 1),
(3, 2, 1),
(4, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `result_data`
--

CREATE TABLE `result_data` (
  `id` int(11) NOT NULL,
  `result_id` int(100) NOT NULL,
  `subject_id` int(100) NOT NULL,
  `marks` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result_data`
--

INSERT INTO `result_data` (`id`, `result_id`, `subject_id`, `marks`) VALUES
(6, 2, 1, '50'),
(7, 2, 2, '60'),
(8, 2, 3, '70'),
(9, 2, 4, '90'),
(10, 2, 5, '100'),
(11, 3, 1, '10'),
(12, 3, 2, '30'),
(13, 3, 3, '40'),
(14, 3, 4, '50'),
(15, 3, 5, '60'),
(16, 4, 1, '50'),
(17, 4, 2, '60'),
(18, 4, 3, '70'),
(19, 4, 4, '80'),
(20, 4, 5, '90');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `email`, `password`, `cpassword`) VALUES
(1, '\r\n             ff', 'fareeya@gmail.com', 'fff', 'fff'),
(2, '\r\n             fff', 'fariya12@gmail.com', 'fariya12', 'fariya12'),
(3, '\r\n             ff', 'arwa@gmail.com', '$2y$10$sCuy1o428KuR8Dnyn6KXIuqTgqrNci4VWM/49VV5HhIbq5.Dip1.K', '$2y$10$ER8IBEFxlI0WSpu.opQ67enWXrOvr3yXmjS3J3vIqdu2Hjs22NtcG'),
(4, '\r\n             tt', 'tt@gmail.com', '$2y$10$9yWdZzkzgoPRlkJ8WlpKDugUZM0Xn2PeDxva0957F9XT4luez4QQK', '$2y$10$NhL4L3nTuJybH1Sk.jEJaOteGvE9iCnjhPjur.eRX8BOg0kjGIoyK');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`) VALUES
(1, 'English'),
(2, 'Hindi'),
(3, 'Math'),
(4, 'Science'),
(5, 'EVS');

-- --------------------------------------------------------

--
-- Table structure for table `table1`
--

CREATE TABLE `table1` (
  `id` int(11) NOT NULL,
  `cellid` int(11) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `teacher` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table1`
--

INSERT INTO `table1` (`id`, `cellid`, `subject`, `teacher`) VALUES
(1, 1, 'computer', 'Abass'),
(1, 1, '', 'Abass'),
(1, 1, '', 'ahmad'),
(1, 1, 'computer', 'Abass'),
(1, 1, 'computer', ''),
(1, 1, 'computer', 'Abass'),
(0, 1, 'computer', 'Abass');

-- --------------------------------------------------------

--
-- Table structure for table `table2`
--

CREATE TABLE `table2` (
  `id` int(11) NOT NULL,
  `cellid` int(11) NOT NULL,
  `teacher` varchar(20) NOT NULL,
  `subject1` varchar(10) NOT NULL,
  `subject2` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table2`
--

INSERT INTO `table2` (`id`, `cellid`, `teacher`, `subject1`, `subject2`) VALUES
(1, 1, 'Abass', 'computer', 'computer');

-- --------------------------------------------------------

--
-- Table structure for table `table3`
--

CREATE TABLE `table3` (
  `id` int(11) NOT NULL,
  `cellid` int(11) NOT NULL,
  `teacher1` varchar(20) NOT NULL,
  `subject1` varchar(10) NOT NULL,
  `teacher2` varchar(20) NOT NULL,
  `subject2` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table3`
--

INSERT INTO `table3` (`id`, `cellid`, `teacher1`, `subject1`, `teacher2`, `subject2`) VALUES
(1, 1, 'Nadeem', 'phyiscs', 'Nadeem', 'phyiscs');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `seat` varchar(255) DEFAULT NULL,
  `enrollno` varchar(255) DEFAULT NULL,
  `batch` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`classId`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table2`
--
ALTER TABLE `table2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table3`
--
ALTER TABLE `table3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `classId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `table2`
--
ALTER TABLE `table2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `table3`
--
ALTER TABLE `table3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
