

<html>
<head>
<title> Retrieved Data</title>
</head>
<body>
<label>Subject</label>
	<input name="subject" type="text" value='<?php echo $subject; ?>'/>
<label>Teacher</label>
	<input name="teacher" type="text" value='<?php echo $teacher; ?>'/>
</body>
</html>