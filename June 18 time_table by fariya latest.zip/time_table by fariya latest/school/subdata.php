<?php
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'interactivetimetable');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
if(isset($_POST)& !empty($_POST)){

$sub=$_POST['subname'];
$class=$_POST['class'];
$subt=$_POST['subteacher'];

$sql="INSERT INTO subject(sname,class,subteacher)
VALUES('$sub','$class','$subt')";
if($connection->query($sql)==TRUE){
	print '<script> alert("The Student Data Has been Succesfuly Uploads");</script>';
}
else{
	
echo"There is an Error".$sql."<br>".$connection->error;
}
}
?>