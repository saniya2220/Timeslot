<?php
	
	$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'smart_time_table1');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
$id = $_GET['id'];
if(isset($_POST)& !empty($_POST)){
$tid=$_POST['tid'];
$tname=$_POST['name'];
$tfname=$_POST['fname'];
$tqual=$_POST['qual'];
$tsub=$_POST['subject'];
$tphone=$_POST['phone'];
$tadd=$_POST['address'];
$tgender=$_POST['gender'];
$temail=$_POST['email'];




$UpdateSql = "UPDATE `teacher` SET  tid= '$tid',tname='$tname',
tfname='$tfname',tqualification='$tqual',tsubject='$tsub',tphone='$tphone',taddress='$tadd',gender='$tgender',email='$temail',
  WHERE tid=$id";
	$res = mysqli_query($connection, $UpdateSql);
	if($res){
		header('location:teacheroutput.php');
	
	}
	else{
		echo "Failed to update data.";
	}
}
?>

