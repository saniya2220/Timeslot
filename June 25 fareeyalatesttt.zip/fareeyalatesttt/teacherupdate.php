
<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
@$userRow=mysqli_fetch_array($res);
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>

    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->

</head>
<body class="size-1140">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>view </strong>Class</p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                  
                     <li ><a href="front.php">Home</a></li>

                      <li><a href="ttview.php">Time Table</a></li> 
                      
                      <li><a href="about.php">About Us</a></li>
                      
                      <li><a href="service.php">Services</a></li>
                      <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    <nav >

        <div  class="line">
            
            <div class="top-nav s-11 l-11">
               
                <ul class="left">
                      <li><a href="class.php" > Class </a> </li>
                    <li><a href="teacher.php" > Teachers </a> </li>
                    <li><a href="subject.php">Subject</a></li>
                   <li><a href="ttview.php">Timetable View</a></li>
		
					

          </div>
        </div>
		</nav>
    
</header>
<br><br><br><br><br><br><br><br><br><br>


<section>
 <h3 align=" center" > UPDATE TEACHER</h3>
 <div align="center" >  
	 <div class="materialContainer" >
           
                <div class="box" >
                    <div class="col-md-12">
    <form class="modal-content animate"method="post"  action="teacheroutput.php">
	<br><br><br><br>

         
                        
                      
   <?php 


@$id = $_GET['tid'];
//$sql2 = "SELECT * FROM `teacher` WHERE tid = $id";

$res=mysqli_query($con, "SELECT * FROM `teacher` WHERE tid = $id");
while(@$row=mysqli_fetch_array($res))
{
	$id=$row['tid'];
	$name=$row['tname'];
	$fname=$row['tfname'];
	$qul=$row['tqualification'];
	$sub=$row['tsubject'];
	$phon=$row['tphone'];
	$add=@$row['taddress'];
	$gen=$row['gender'];
	$email=$row['email'];
	
	
	?>
          
  <div class="form-row">
  <div class="form-group col-md-4">
      <label for="inputState">Teacher Id</label>
      <input type="text" name="tid" class="form-control" value="<?php echo $id;?>" placeholde="<?php echo $id;?>"required/>
    </div>
   <div class="form-group col-md-4">
                           <label >Teacher Name</label>
                        <input type="text" name="tname" class="form-control"value="<?php echo $name;?>" placeholde="<?php echo $name;?>"required/>
    </div>
    <div class="form-group col-md-4">
      <label >Father Name</label>
      <input type="text" name="tfname" class="form-control"value="<?php echo $fname;?>" placeholde="<?php echo $fname;?>" required/>
    </div>
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-4">
      <label for="inputState">Qualification</label>
      <input type="text" name="tqual" class="form-control" value="<?php echo $qul;?>" placeholde="<?php echo $qul;?>"  required/>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Subject</label>
      <input type="text" name="tsubject" class="form-control" value="<?php echo $sub;?>" placeholde="<?php echo $sub;?>"  required />

    </div>
    <div class="form-group col-md-4">
      <label for="inputState">PHone No</label>
      <input type="text" name="tphone" class="form-control" value="<?php echo $phon;?>" placeholde="<?php echo $phon;?>" required/>

    </div>
	
  </div>
  <div class="form-row">
    
    <div class="form-group col-md-4">
      <label for="inputState">Address</label>
      <input type="text" name="taddress" class="form-control" value="<?php echo $add;?>" placeholde="<?php echo $add;?>" required/>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Gender</label>
	  <select name="tgender" class="form-control">
        <option selected>Choose...</option>
        <option>Male</option>
		<option>Female</option>
      </select>
     
    </div>
	<div class="form-group col-md-6">
      <label for="inputCity">Email</label>
      <input type="text" name="temail" class="form-control" value="<?php echo $email;?>" placeholde="<?php echo $email;?>" required/>
    </div>
  </div>
  
  <button type="submit" class="btn btn-primary">submit</button>
  <br><br><br><br>
</form>
     <?php } ?>         </div>	
                    </div>
                </div>

           
        </div>
</section>
<br><br><br>

<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>

<?php
	
	
if(isset($_POST)& !empty($_POST)){
$tid=$_POST['tid'];
$tname=$_POST['tname'];
$tfname=$_POST['tfname'];
$tqual=$_POST['tqual'];
$tsub=$_POST['tsubject'];
$tphone=$_POST['tphone'];
$tadd=$_POST['taddress'];
$tgender=$_POST['tgender'];
$temail=$_POST['temail'];




$UpdateSql = "UPDATE `teacher` SET  tid= '$tid',tname='$tname',
tfname='$tfname',tqualification='$tqual',tsubject='$tsub',tphone='$tphone',taddress='$tadd',gender='$tgender',email='$temail',
  WHERE tid=$id";
	$res = mysqli_query($connection, $UpdateSql);
	if($res){
		header('location:teacheroutput.php');
	
	}
	else{
		echo "Failed to update data.";
	}
}
?>
