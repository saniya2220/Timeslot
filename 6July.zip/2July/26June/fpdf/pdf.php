<?php

						
		require("fpdf.php");
		$pdf=new FPDF();
		$pdf->AddPage();
		$pdf->SetFont("Arial","B",16);
		$pdf->Cell(0,10,"SCHOOL SYSTEM TIME TABLE",1,1,"C");
		$pdf->Cell(45,10,"Teache ID:",1,0,"C");
		$pdf->Cell(45,10,"Period:",1,0,"C");
		$pdf->Cell(55,10,"Name:",1,0,"C");
		$pdf->Cell(45,10,"Subject:",1,1,"C");
						$mysqli = new mysqli('localhost','root','');
						$mysqli->select_db("smart_time-table1");
						$query="select * from testtable.php";
						$run = $mysqli->query($query);
						// while loop for get data from database and print it on page....
						while ($row=$run->fetch_array())
						{
						
							
							$period=$row['period'];
							$teacherName=$row['teacherName'];
							$subjectName=$row['subjectName'];
							
				
								$pdf->Cell(45,10,$period,1,0,"C");
								$pdf->Cell(55,10,$teacherName,1,0,"C");
								$pdf->Cell(45,10,$subjectName,1,1,"C");
							
						}
		$pdf->output();
		
							
?>