<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
//if( !isset($_SESSION['user']) ) {
  //  header("Location: index.php");
   // exit;
//}
// select loggedin users detail
//$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
//@$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    
    <?php include 'link.php'; ?>

    <!----  links about main content      ---->

    
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
        ============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
        ============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- educate icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
        ============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
        ============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
        
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<?php include 'connection.php'; ?>
  <?php include 'includes/side_bar.php'; ?>
  
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href=""><img src="" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
         <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                <i class="educate-icon educate-nav"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                                <li class="nav-item"><a href="#" class="nav-link">Dashboard</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                       <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">  
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                            <img src="img/product/pro4.jpg" alt="" />
                                                            <span class="admin-name">Administrator</span>
                                                        </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-settings author-log-ic"></span>Settings</a>
                                                        </li>
                                                        <li><a href="logout.php"><span class="edu-icon edu-locked author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="index.php">Home <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="index.php">Dashboard </a></li>
                                               
                                            </ul>
                                        </li>
										   
                                      <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="time_table.php">Time Table <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li> 
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="teacher.php">Teachers <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="subject.php">Subjects <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="class.php">Classes<span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
				                       <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="semester.php">Semesters <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="lecture.php">Lectures <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <br>
            <br>
            <!-- Mobile Menu end -->
        </div>
              <!-- Static Table Start -->
        <div class="static-table-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list">
                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1>Add Teachers</h1>
                                </div>
                            </div>
                              <!-- Button to Open the Modal -->
                             <br>
                            <div class="sparkline8-graph">
                                <div class="static-table-list">
                                    <div align="center"> <a class="btn btn-info btn-primary" style="color: white; background-color: #002e63; border-color: #002e63; " data-toggle="modal" data-target="#modal" >Add New Teacher</a></div>
                                    <br>
                                    <table class="table" id="table">
                                        <thead>
                                            <th>Teacher ID</th>
                                            <th>Teacher Name</th>
                                            <th>Subject</th>
                                            <th>Phone No</th>
                                            <th>Email</th>
                                            
                                        </thead>
                                        <?php 
                                        //$sql2="SELECT * FROM teacher";
                                        $res=mysqli_query($con, "SELECT * FROM teacher");
                                        while(@$row=mysqli_fetch_array($res))
                                        {
                                            $id=$row['tid'];
                                            $name=$row['teacherName'];
                                            $sub=$row['tsubject'];
                                            $phon=$row['tphone'];
                                            $email=$row['email'];
                                        ?>	
                                    <tbody>
                                        <tr>
                                            <td><?php echo $id  ?></td>
                                            <td><?php echo $name?></td>
                                            <td><?php echo $sub?></td>
                                            <td><?php echo $phon?></td>
                                            <td><?php echo $email?></td>
                                            
                                        </tr>
                                        </tbody>
                                        <?php } ?>
                                    </table>
                                   <div class="modal fade" id="modal" role="dialog">
                                        <div class="modal-dialog modal-sm">s
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 id="modalHead" align="center"> Add Teacher Detail</h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>  
                                                </div>
                                                <div class="modal-body" style="padding:20px 50px;">
                                                    <form role="form" id='addTeacher' method="post"  action="teacher.php">
                                                        
                                                                <label for="inputState">Teacher Id</label>
                                                                <input type="text" name="tid" class="form-control" placeholder="Enter teacher Id  " />
                                                                <label >Teacher Name</label>
                                                                <input type="text" name="name" class="form-control" placeholder="Enter Name" maxlength="100"   required/>
                                                                <label >Father Name</label>
                                                                <input type="text" name="fname" class="form-control" placeholder="Father Name" maxlength="100"  required/>
                                                                <label for="inputState">Qualification</label>
                                                                <input type="text" name="qual" class="form-control" placeholder="Enter Qualification" maxlength="50"  required/>
                                                                <label for="inputState">Subject</label>
                                                                <input type="text" name="subject" class="form-control" placeholder="Enter Subject" maxlength="50"  required />
                                                                <label for="inputState">PHone No</label>
                                                                <input type="text" name="phone" class="form-control" placeholder="Enter Phone No." maxlength="12" required/>
                                                                <label for="inputState">Address</label>
                                                                <input type="text" name="address" class="form-control" placeholder="Enter Address" maxlength="100"  required/>
                                                                <label for="inputZip">Gender</label>
                                                                <select name="gender" class="form-control">
                                                                    <option selected>Choose...</option>
                                                                    <option>Male</option>
                                                                    <option>Female</option>
                                                                </select>
                                                                <label for="inputCity">Email</label>
                                                                <input type="text" name="email" class="form-control" placeholder="Enter email" maxlength="50"  required/>   
                                                        <button type="submit" style="height:1cm;width:3cm;color:#ffff;background-color:#002e63;border-color:#002e63;" id="" class="btn btn-success center-block"><span class="glyphicon glyphicon-time"></span> Submit</button>
                                                    </form> 
                                                </div>                            
                                            </div>
                                        </div>
                                    </div>
        
                                    
                                        <!-- Insert  Modal -->
                                    
                                    </div>

                                    
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
        </div>
              </div>  <!-- WRAPPER END -->


    <?php
if(isset($_POST)& !empty($_POST)){
$tid=$_POST['tid'];
$name=$_POST['name'];
$fname=$_POST['fname'];
$qual=$_POST['qual'];
$sub=$_POST['subject'];
$phone=$_POST['phone'];
$add=$_POST['address'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$sql="INSERT INTO teacher( tid,teacherName,tfname,tqualification,tsubject,tphone,tAddress ,gender,email)
VALUES('$tid','$name','$fname','$qual','$sub','$phone','$add','$gender','$email')";
if($connection->query($sql)==TRUE){
    print '<script> alert("The Teacher Data Has been Succesfuly Uploads");</script>';
}
else{
    
echo"There is an Error".$sql."<br>".$connection->error;
}
}
?>

<?php
    
    
if(isset($_POST)& !empty($_POST)){
$tid=$_POST['tid'];
$teacherName=$_POST['name'];
$tfname=$_POST['fname'];
$tqual=$_POST['qual'];
$tsub=$_POST['subject'];
$tphone=$_POST['phone'];
$tadd=$_POST['address'];
$tgender=$_POST['gender'];
$temail=$_POST['email'];




$UpdateSql = "UPDATE `teacher` SET  tid= '$tid',teacherName='$teacherName',
tfname='$tfname',tqualification='$tqual',tsubject='$tsub',tphone='$tphone',taddress='$tadd',gender='$tgender',email='$temail',
  WHERE tid=$id";
    $res = mysqli_query($connection, $UpdateSql);
    if($res){
        header('location:teacheroutput.php');
    
    }
    else{
        echo "Failed to update data.";
    }
}
?>

                        
 
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/morrisjs/raphael-min.js"></script>
    <script src="js/morrisjs/morris.js"></script>
    <script src="js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="js/calendar/moment.min.js"></script>
    <script src="js/calendar/fullcalendar.min.js"></script>
    <script src="js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>



</body>
</html>
<?php ob_end_flush(); ?>


