<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_time_table1";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "SELECT userId, userName, userEmail FROM users";
//$result = $conn->query($sql);

//if ($result->num_rows > 0) {
    // output data of each row
  //  while($row = $result->fetch_assoc()) {
    //    echo "<br> id: ". $row["userId"]. " - Name: ". $row["userName"]. " " . $row["userEmail"] . "<br>";
   // }
//} else {
   // echo "0 results";
//}
//$con->close();
?>