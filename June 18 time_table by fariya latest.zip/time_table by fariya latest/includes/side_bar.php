<!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="#"><img class="main-logo" src="images/123.PNG" alt="" /></a>
                <strong><a href="#"><img src="images/cal.PNG" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <br>
                        <br>
                        <li>
                            <a title="Landing Page" href="ttview.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Generate Time Table</span></a>
                        </li>
                        <li>
                            <a title="Landing Page" href="testtable.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">View Time Table</span></a>
                        </li>
                        <li>
                            <a title="Landing Page" href="testtable1.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Update Time Table</span></a>
                        </li>
                        <li>
                            <a class="" href="teacher.php" aria-expanded="false"><span class="educate-icon educate-professor icon-wrap"></span> <span class="mini-click-non">Teachers</span></a>
                            
                        </li>
                        
                        <li>
                            <a class="" href="subject.php" aria-expanded="false"><span class="educate-icon educate-course icon-wrap"></span> <span class="mini-click-non">Subjects</span></a>
                    
                        </li>
                        <li>
                            <a class="" href="class.php" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Classes </span></a>
                            
                        </li>
                        <li>
                            <a class="" href="Days.php" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Add Days</span></a>
                            
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>

    </div>