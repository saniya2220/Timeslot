<?php

require_once 'dbconnect.php';
include_once 'connection.php';
 $rs=mysqli_query( $connection,"DELETE FROM  config_timetable  ");
 
  if(isset($_POST['submit']));
if(isset($_POST)& !empty($_POST))
{

               $lecturesPerDay=$_POST['lecturesPerDay'];
                $startTime=$_POST['startTime'];
                $endTime=$_POST['endTime'];
                $breakAfter=$_POST['breakAfter'];
                $breakDuration=$_POST['breakDuration'];
                $lecturesDuration=$_POST['lecturesDuration'];
}


$sq="INSERT INTO config_timetable(lecturesPerDay,startTime,endTime,breakAfter, breakDuration,lecturesDuration)
VALUES('$lecturesPerDay','$startTime',' $endTime','$breakAfter' ,'$breakDuration',' $lecturesDuration')";

if($connection->query($sq)==TRUE){
	 $rs=mysqli_query( $connection,"DELETE FROM  timetable  ");
	header("Location: testtable1.php");

}
else{
	
echo"There is an Error".$sq."<br>".$connection->error;
}


?>