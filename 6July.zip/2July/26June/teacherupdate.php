
<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
//if( !isset($_SESSION['user']) ) {
  //  header("Location: index.php");
    //exit;
//}
// select loggedin users detail
//$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
//$userRow=mysqli_fetch_array($res);
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>

    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->

</head>
<body class="size-1140">
<!-- TOP NAV WITH LOGO -->



<section>
 <h3 align=" center" > Update Teacher</h3>
 <div align="center" >  
   <div class="materialContainer">
    <div class="box">
      <div class="col-md-12">
        <form class="modal-content animate"method="post">
          <br><br>                      
          <?php 
          $id = $_GET['id'];
          $SelSql = "SELECT * FROM `teacher` WHERE tid = $id";
          $res = mysqli_query($connection, $SelSql);
          $r = mysqli_fetch_assoc($res);
          $techid1=$r['tid'];
          $techname1=$r['tname'];
          $techfname1=$r['tfname'];
          $techqualification1=$r['tqualification'];
          $techsubject1=$r['tsubject'];
          $techphone1=$r['tphone'];
          $techaddress1=$r['taddress'];
          $techgender1=$r['tgender'];
          $techemail1=$r['temail'];
          ?>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label >Teacher Id</label>
              <input type="text" name="tid" class="form-control"
              value="<?php echo $techid1;?>" placeholde="<?php echo $techid1;?>" maxlength="15" />
            </div>
            <div class="form-group col-md-4">
              <label >Teacher Name:</label>
              <input type="text" name="tname" class="form-control"
              value="<?php echo $techname1;?>" placeholde="<?php echo $techname1;?>" maxlength="100" />
            </div>
            <div class="form-group col-md-4">
              <label >Father Name</label>
              <input type="text" name="tfname" class="form-control"value="<?php echo $techfname1;?>" placeholde="<?php echo $techfname1;?>" required/>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label for="inputState">Qualification</label>
              <input type="text" name="tqualification" class="form-control" value="<?php echo $techqualification1;?>" placeholde="<?php echo $techqualification1;?>"  required/>
            </div>
            <div class="form-group col-md-4">
              <label for="inputState">Subject</label>
              <input type="text" name="tsubject" class="form-control" value="<?php echo $techsubject1;?>" placeholde="<?php echo $techsubject1;?>"  required />
            </div>
            <div class="form-group col-md-4">
              <label for="inputState">Phone No</label>
              <input type="text" name="tphone" class="form-control" value="<?php echo $techphone1;?>" placeholde="<?php echo $techphone1;?>" required/>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label for="inputState">Address</label>
              <input type="text" name="taddress" class="form-control" value="<?php echo $techaddress1;?>" placeholde="<?php echo $techaddress1;?>" required/>
            </div>
            <div class="form-group col-md-2">
              <label for="inputZip">Gender</label>
              <select name="tgender" class="form-control">
                <option selected>Choose...</option>
                <option>Male</option>
                <option>Female</option>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label for="inputCity">Email</label>
              <input type="text" name="temail" class="form-control" value="<?php echo $techemail1;?>" placeholde="<?php echo $techemail1;?>" required/>
            </div>
          <br>
          <button type="submit" style="color: white; background-color: #002e63; border-color: #002e63;" class="btn btn-success center-block"><span class="glyphicon glyphicon-time"></span> Submit</button>
          <br><br>
        </form>
        </div>
      </div>
    </div>
  </div>
</section>
<br><br><br>

<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>


<?php
if(isset($_POST)& !empty($_POST)){
$techid=$_POST['tid'];
$techname=$_POST['tname'];
$techfname=$_POST['tfname'];
$techqualification=$_POST['tqualification'];
$techsubject=$_POST['tsubject'];
$techphone=$_POST['tphone'];
$techaddress=$_POST['taddress'];
$techgender=$_POST['tgender'];
$techemail=$_POST['temail'];

$UpdateSql = "UPDATE `teacher` SET  tid= '$techid', tname='$techname', tfname= '$techfname', tqualification='$techqualification',tsubject= '$techsubject', tphone='$techphone',taddress= '$techaddress', tgender='$techgender', temail='$techemail'
  WHERE tid=$id";
  $res = mysqli_query($connection, $UpdateSql);
  if($res){
    header('location: teacher.php');
  }else{
    echo "Failed to update data.";
  }
}
?>
