<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';


// if session is not set this will redirect to login page
//if( !isset($_SESSION['user']) ) {
  //  header("Location: index.php");
    //exit;
//}
// select loggedin users detail
//$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
//@$userRow=mysqli_fetch_array($res);

 $lecturesPerDay='';
    $startTime='';
    $batch='';
        $lecturesDuration='';
	
	
	//$sql2="SELECT * FROM config_timetable";
$res=mysqli_query($con, "SELECT * FROM config_timetable");
while($row=mysqli_fetch_array($res))
{
	           $lecturesPerDay=$row['lecturesPerDay'];
                $startTime=$row['startTime'];
                $endTime=$row['batch'];
                
                $lecturesDuration=$row['lecturesDuration'];
            }  


   
?>
<!DOCTYPE html>
<html>
<head>
    
    <?php include 'link.php'; ?>

    <!----  links about main content      ---->

    
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/.ico">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
        ============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
        ============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- educate icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
        ============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
        ============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
        
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<?php include 'connection.php'; ?>
  <?php include 'includes/side_bar.php'; ?>
  
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.php"><img src="" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
         <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                    <i class="educate-icon educate-nav"></i>
                                                </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                                <li class="nav-item"><a href="#" class="nav-link">Dashboard</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                       <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">  
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                            <img src="img/product/pro4.jpg" alt="" />
                                                            <span class="admin-name">Administrator</span>
                                                            <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                        </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-settings author-log-ic"></span>Settings</a>
                                                        </li>
                                                        <li><a href="logout.php"><span class="edu-icon edu-locked author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="index.php">Home <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="index.php">Dashboard </a></li>
                                               
                                            </ul>
                                        </li>
										   
                                      <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="time_table.php">Time Table <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li> 
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="teacher.php">Teachers <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="subject.php">Subjects <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="class.php">Classes<span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
				                      
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="lecture.php">Lectures <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="day.php">Days  <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="user.php">Users <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
              <!-- Static Table Start -->
        <div class="static-table-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list">
                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1>View Timetable</h1>
                                </div>
                            </div>
                            <div class="sparkline8-graph">
                                <div class="static-table-list">
                                    <center>
                                        <a href='fpdf/pdf.php'><input type='submit' value='Export PDF File' style='color:white;height:35px;width:200px;background-color:#002e63;border:1px ;border-radius:4px;'>
                                        </a>
                                    </center>
                                   
				
            <table class="table table-striped  table-responsive" border="1">
                <center>
                <thead>
                    <tr align="center" bgcolor="lightgray">
                    
                        <th><center>Days</center></th>
                        <center>
                       <?php
                            $lectureTime='';
                            $lecturesDurationArray='';
                            
                            if($lecturesPerDay!=''&& $lecturesDuration!=''){
                                $lecturesDurationArray=explode(',',$lecturesDuration);
                                
                                $lectureTime=$startTime;
                                
                                for($i=1;$i<=$lecturesPerDay;$i++){
                                    
                                    echo'<th bgcolor="#1E90FF"; font-color="#ffff" ><label name='.$i.'>'.$i.'</label><br>'.$lectureTime;
                                  
                                    @$lectureTime=incrementTimeBy($lectureTime, $lecturesDuration);
                                    echo '---' ;
                                    echo $lectureTime;  
                                    echo '</th>'; 
                                }
                            }
                            
                            function incrementTimeBy($time,$min){
                                list($hh,$mm)=explode(':',$time);
                                
                                @$hh=($hh+floor(($mm+$min)/60))%12;
                                @$mm=($mm+$min)%60;
                                
                                return ($hh==0?12:$hh).':'.($mm<10?'0'.$mm:$mm);
                            }
                            ?>
                        </center>
                    </tr>
                </thead>
                </center>
            <tbody>  
            <center>
           <?php
               $rs=mysqli_query( $connection,"SELECT * FROM days ");
                $rowcount=mysqli_num_rows($rs);
                // populate table with existing records
                if($rs and $rowcount>0){
                                     for($j=1;$j<=$rowcount;$j++){
                    while($row=$rs->fetch_array())
                    {
                      $day=$row['day'];
    
                   echo "<tr>".
                            "<th hidden='hidden'>".$row['day']."</th>".
                            "<th width='1%' height='1%' >".$row['day']."</th>";
                      
                    
                            
                            for($i=1; $i<=$lecturesPerDay;$i++)
                            {
                                echo "<td  width='5%'; height='3%' id='".@$row['day']."_".$i."'>";
                                //$sql2="SELECT * FROM timetable WHERE period= $i && classId=$classId" ;
                                $res=mysqli_query($con, "SELECT * FROM timetable WHERE period= $i && $day=$day");
                                while(@$row=mysqli_fetch_array($res))
                                {
                                    $sub=$row['subjectName'];
                                    $tec=$row['teacherName'];
                                    echo $tec;
                                    echo"<br>";
                                    echo $sub;
                                    }
                                    echo "</td>";   
                                   
                            }
                    }   
                            
                        echo "</tr>";
                    }   
    
                }
            ?>
                 
						   
              </tbody>
             </table>

                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
        
        
</div>  <!-- WRAPPER END -->



                        
 
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/morrisjs/raphael-min.js"></script>
    <script src="js/morrisjs/morris.js"></script>
    <script src="js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="js/calendar/moment.min.js"></script>
    <script src="js/calendar/fullcalendar.min.js"></script>
    <script src="js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
    
    

	



</body>
</html>

                        
                        
                    
