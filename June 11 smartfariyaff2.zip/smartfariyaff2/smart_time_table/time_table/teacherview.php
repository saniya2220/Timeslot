<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';


// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysqli_fetch_array($res);

 $lecturesPerDay='';
    $startTime='';
    $endTime='';
    $breakAfter='';
    $breakDuration='';
    $lecturesDuration='';
	
	
	//$sql2="SELECT * FROM config_timetable";
$res=mysqli_query($con, "SELECT * FROM config_timetable");
while($row=mysqli_fetch_array($res))
{
	             $lecturesPerDay=$row['lecturesPerDay'];
                $startTime=$row['startTime'];
                $endTime=$row['endTime'];
                $breakAfter=$row['breakAfter'];
                $breakDuration=$row['breakDuration'];
                $lecturesDuration=$row['lecturesDuration'];
            }  


   
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>
    <link rel="stylesheet" href="styles.css" type="text/css" />
    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
   
</head>
<body class="size-1140" bgcolor="#C0DCC0">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>Add  </strong>Class</p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                  
                     <li ><a href="front.php">Home</a></li>

                      <li><a href="ttview.php">Time Table</a></li> 
                      
                      <li><a href="about.php">About Us</a></li>
                  
                      <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    <nav >

        <div  class="line">
            
            <div class="top-nav s-11 l-11">
               
                <ul class="left">
                      <li><a href="class.php" > Class </a> </li>
                    <li><a href="teacher.php" > Teachers </a> </li>
                    <li><a href="subject.php">Subject</a></li>
                   <li><a href="ttview.php">Timetable View</a></li>
		
					

          </div>
        </div>
		</nav>
</header>
<style>
        .modal-header, h4, .close {
            background-color: #5cb85c;
            color:white !important;
            text-align: center;
            font-size: 20px;
        }
        .modal-footer {
            background-color: #f9f9f9;
        }
        .modalTable thead tr th{
            
            background-color: transparent!important;
            font-weight: bold;
            color: black;
            
        }
        
        .modalTable tbody tr:hover{
            
            background-color: #f2f2f2!important;
            color: black;                       
        }
        
        
       
  </style>

<br><br><br><br><br><br><br><br><br><br>
 <section>
<body >

<div align="left">
 <div class='container fixHeader'>

             <form class="customform" action="testtable.php">
                <div class="s-12 m-12 l-4" align="left" ><button class="btn btn-info btn-primary" align="center" type="submit">  VIEW TIME TABLE </button></div>
            </form>
			<form class="customform" action="teacherview.php">
                <div class="s-12 m-12 l-4" align="center"><button class="btn btn-info btn-primary" align="center" type="submit">VIEW TEACHER TIMETABLE </button></div>
            </form>
			<form class="customform" action="testtable1.php">
                <div class="s-12 m-12 l-4" align="center"><button class="btn btn-info btn-primary" align="center" type="submit"> UPDATE TEACHER TIMETABLE </button></div>
            </form>
	
        
             <?php
                    echo '<h3>  Start Time: '. $startTime. '</h3><h3> End Time: '. $endTime .'</h3>';
					echo '<br><br>';
                ?> 
				 <table class="table table-striped  table-responsive" border="1">
                    <thead>
                <tr align="center" bgcolor="lightgray">
                    <th>Teacher id</th>
                    <th>Teacher Name</th>
                    <?php
                    
                    $lectureTime='';
                    $lecturesDurationArray='';
                    
                    if($lecturesPerDay!=''&& $lecturesDuration!=''){
                        $lecturesDurationArray=explode(',',$lecturesDuration);
                        
                        $lectureTime=$startTime;
                        
                        for($i=1;$i<=$lecturesPerDay;$i++){
                            
                            echo '<th bgcolor="#5cb85c"><label name='.$i.'>'.$i.'</label><br>'.$lectureTime;
                          
                            @$lectureTime=incrementTimeBy($lectureTime, $lecturesDurationArray[$i-1]);
                            echo '---' ;
							echo $lectureTime;  
							echo '</th>'; 
							if($i==$breakAfter){
							echo'<th>';
							echo'break<br>'.$lectureTime;
							$lectureTime=incrementTimeBy($lectureTime,$breakDuration);
							echo '---' ;
							echo $lectureTime;
							echo '</th>'; 
							}
                        }
                    }
                    
                    function incrementTimeBy($time,$min){
                        list($hh,$mm)=explode(':',$time);
                        
                        @$hh=($hh+floor(($mm+$min)/60))%12;
                        @$mm=($mm+$min)%60;
                        
                        return ($hh==0?12:$hh).':'.($mm<10?'0'.$mm:$mm);
                        
                    }
                    
                    ?>
                </tr>
            </thead>  
<?php   $rs=mysqli_query( $connection,"SELECT *   FROM teacher");
                $rowcount=mysqli_num_rows($rs);
            
            
                if($rs and $rowcount>0){
                                     
                    while($row=$rs->fetch_array()){
			          $tid=$row['tid'];
					  $tname=$row['tname'];
					  
	
                   echo "<tr>".
                            "<th hidden='hidden'>".$row['tid']."</th>".
                            "<th width='1%' height='1%' >".$row['tid']."</th>".
                            "<th width='2%'>".$row['tname']."</th>";
					
                            
                            for($i=1; $i<=$lecturesPerDay;$i++){
                                echo "<td  width='5%'; height='3%' id='".$row['tname']."_".$i."'>";
								
								$sql2="SELECT * FROM timetable WHERE period=$i  && teacherName='$tname'" ;
                                                $res=mysql_query($sql2);
                                            while($row=mysql_fetch_array($res))
											{
   
                                         $sub=$row['subjectName'];
                                         $classid=$row['classId'];
										 echo $sub;
										 
										  $sql3="SELECT * FROM class WHERE classId= $classid " ;
                                                $res1=mysql_query($sql3);
                                            while($row=mysql_fetch_array($res1))
											{
											$classname=$row['className'];
											}
											       
												   echo "<br>";     		 
                                                  echo $classname;
                                            }
								
											
                                         
   
                                            echo "</td>";   
											if($i==$breakAfter){
							echo"<td width='5% height='3%' rowspan='' >";
							
							echo"</td>";
							} 
                                   
                            }
					}   
                            
                        echo "</tr>";
                }   
	

   ?>
						   </table>
</div>
</div>
	



</body>
</html>
