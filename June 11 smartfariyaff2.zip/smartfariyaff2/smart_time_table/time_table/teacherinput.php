<?php
ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>
    <link rel="stylesheet" href="styles.css" type="text/css" />
    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
   
</head>
<body class="size-1140" bgcolor="#C0DCC0">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>Add  </strong>Class</p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                  
                     <li ><a href="front.php">Home</a></li>

                      <li><a href="ttview.php">Time Table</a></li> 
                      
                      <li><a href="about.php">About Us</a></li>
                      
                      <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    <nav >

        <div  class="line">
            
            <div class="top-nav s-11 l-11">
               
                <ul class="left">
                      <li><a href="class.php" > Class </a> </li>
                    <li><a href="teacher.php" > Teachers </a> </li>
                    <li><a href="subject.php">Subject</a></li>
                   <li><a href="ttview.php">Timetable View</a></li>
		
					

          </div>
        </div>
		</nav>
</header>

<br><br><br><br><br><br><br><br><br><br>
 <section>
    <h3 align=" center" > ADD TEACHER Detail</h3>
    <div align="center" >  
	 <div class="materialContainer">
           
                <div class="box">
                    <div class="col-md-12">
					<form class="modal-content animate" method="post" action="teacherinput.php"><br>
  <div class="form-row">
  <div class="form-group col-md-4">
      <label for="inputState">Teacher Id</label>
      <input type="text" name="tid" class="form-control" placeholder="Enter teacher Id  " required/>
    </div>
   <div class="form-group col-md-4">
                           <label >Teacher Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter Name" maxlength="15"   required/>
    </div>
    <div class="form-group col-md-4">
      <label >Father Name</label>
      <input type="text" name="fname" class="form-control" placeholder="Father Name" maxlength="15"  required/>
    </div>
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-4">
      <label for="inputState">Qualification</label>
      <input type="text" name="qual" class="form-control" placeholder="Enter Qualification" maxlength="15"  required/>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Subject</label>
      <input type="text" name="subject" class="form-control" placeholder="Enter Subject" maxlength="15"  required />

    </div>
    <div class="form-group col-md-4">
      <label for="inputState">PHone No</label>
      <input type="text" name="phone" class="form-control" placeholder="Enter Phone No." maxlength="15" required/>

    </div>
	
  </div>
  <div class="form-row">
    
    <div class="form-group col-md-4">
      <label for="inputState">Address</label>
      <input type="text" name="address" class="form-control" placeholder="Enter Address" maxlength="15"  required/>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Gender</label>
	  <select name="gender" class="form-control">
        <option selected>Choose...</option>
        <option>Male</option>
		<option>Female</option>
      </select>
     
    </div>
	<div class="form-group col-md-6">
      <label for="inputCity">Email</label>
      <input type="text" name="email" class="form-control" placeholder="Enter email" maxlength="15"  required/>
    </div>
  </div>
  
  <button type="submit" class="btn btn-primary">submit</button>
  <br><br><br><br>
</form>
               </div>	
                    </div>
                </div>

           
        </div>



</section>
<br><br><br><br>

</section>
<!-- FOOTER -->
<footer>
    <div class="line">
        <div class="s-12 l-6">
            <p>All copyrights are reserved (2018)</p>
            <p> All images are for the need of project. Don't copy any image.</p>
        </div>
        <div class="s-12 l-6">
            <a class="right" href="http://www.iqrakhan/sites.com" title="Responsee - lightweight responsive framework">Design and coding<br> by Responsee Team</a>
        </div>
    </div>
</footer>
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>
<?php
if(isset($_POST)& !empty($_POST)){
$tid=$_POST['tid'];
$name=$_POST['name'];
$fname=$_POST['fname'];
$qual=$_POST['qual'];
$sub=$_POST['subject'];
$phone=$_POST['phone'];
$add=$_POST['address'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$sql="INSERT INTO teacher( tid,tname,tfname,tqualification,tsubject,tphone,tAddress ,gender,email)
VALUES('$tid','$name','$fname','$qual','$sub','$phone','$add','$gender','$email')";
if($connection->query($sql)==TRUE){
	print '<script> alert("The Teacher Data Has been Succesfuly Uploads");</script>';
}
else{
	
echo"There is an Error".$sql."<br>".$connection->error;
}
}
?>
<?php ob_end_flush(); ?>