<?php


ob_start();
session_start();
require_once 'dbconnect.php';
include_once 'connection.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['signup']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysqli_query($con, "SELECT * FROM signup WHERE id=".$_SESSION['signup']);
$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <?php include 'link.php'; ?>
      <!-- META TAGS -->
        <!--< <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Education master is one of the best educational html template, it's suitable for all education websites like university,college,school,online education,tution center,distance education,computer education">
    <meta name="keyword" content="education html template, university template, college template, school template, online education template, tution center template">
    <!-- FAV ICON(BROWSER TAB ICON) -->
    <link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700%7CJosefin+Sans:600,700" rel="stylesheet">
    <!-- FONTAWESOME ICONS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- ALL CSS FILES -->
    <link href="css/materialize.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
    <link href="css/style-mob.css" rel="stylesheet" /> 

    <!----  links about main content      ---->

    
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- educate icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
		
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<style>
        .modal-header, h4, .close {
            background-color: #5cb85c;
            color:white !important;
            text-align: center;
            font-size: 20px;
        }
        .modal-footer {
            background-color: #f9f9f9;
        }
        .modalTable thead tr th{
            
            background-color: transparent!important;
            font-weight: bold;
            color: black;
            
        }
        
        .modalTable tbody tr:hover{
            
            background-color: #f2f2f2!important;
            color: black;                       
        }
        
        .dropdown {
    float: left;
    overflow: hidden;
}
.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}
       
  </style>
<body>

    <?php include 'connection.php'; ?>
  <?php include 'includes/side_bar.php'; ?>
  <section>
        <!-- TOP BAR -->
        <div class="ed-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ed-com-t1-left">
                            <ul>
                                <li><a href="#">Contact: 5C، Block 5 Nazimabad, Karachi, Karachi City, Sindh 74600, Pakistan</a>
                                </li>
                                <li><a href="#">Phone: (021) 36620857</a>
                                </li>
                            </ul>
                        </div>
                        <div class="ed-com-t1-right">
                            <ul>
                                <li><a href="#!" data-toggle="modal" data-target="#modal1">Sign In</a>
                                </li>
                                <li><a href="#!" data-toggle="modal" data-target="#modal2">Sign Up</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- LOGO AND MENU SECTION -->
        <div class="top-logo" data-spy="affix" data-offset-top="250">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wed-logo">
                            <a href="index.php"><img src="images/logo.png" alt="" />
                            </a>
                        </div>
                        <div class="main-menu">
                            <ul>
                                <li class="about-menu">
                                    <a href="about.php" class="mm-arr">About us</a>
                                </li>
                                <li><a href="contact.php">Contact us</a>
                                </li>
                            </ul>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    </section>
    <!--END HEADER SECTION-->
  
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.php"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
         <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="educate-icon educate-nav"></i>
												</button>
                                        </div>
                                    </div>
                                   
                                       <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                                
                                                
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<img src="img/product/pro4.jpg" alt="" />
															<span class="admin-name">Administrator</span>
															<i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
														</a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        
                                                        <li><a href="#"><span class="edu-icon edu-settings author-log-ic"></span>Settings</a>
                                                        </li>
                                                        <li><a href="logout.php"><span class="edu-icon edu-locked author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="index.php">Home <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="index.php">Dashboard </a></li>
                                               
                                            </ul>
                                        </li>
										   
                                      <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="time_table.php">Time Table <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li> 
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="teacher.php">Teachers <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="subject.php">Subjects <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="class.php">Classes<span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
				                       <li>
									  <a data-toggle="collapse" data-target="#Tablesmob" href="semester.php">Semesters <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="lecture.php">Lectures <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                        <li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="day.php">Days  <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
										<li>
                                        <a data-toggle="collapse" data-target="#Tablesmob" href="user.php">Users <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                           
                                        </li>
                                        

                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control" name="search" id="search">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">teacher</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <!-- Static Table Start -->
        <div class="static-table-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list">
                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1>Basic Table</h1>
                                </div>
                            </div>
                              <!-- Button to Open the Modal -->
                             <div align="right">
                            <button type="button" class="btn btn-info" data-toggle="modal" data-target="#addmodal">  Add new</button>
                            </div>
                             <br>
                            <div class="sparkline8-graph">
                                <div class="static-table-list">
                                    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  

    
		<button  type="button"  class="btn btn-success btn-primary" data-toggle="modal" data-target="#modal" >Create New Timetable</a></button>
	
       <align="right"><button type="button"  class="btn btn-success btn-primary" ><a href="testtable1.php">Update Timetable</a></button> 
		
		<button type="button"  class=" btn btn-success btn-primary" ><a href="testtable.php"> View  Timetable</a></button>
		
          <button type="button"  class="btn btn-success btn-primary" ><a href="teacherview.php">View  Teacher Timetable</a></button>
          
		
    

  


       <!-- Insert  Modal -->
    <div class="modal fade" id="modal" role="dialog">
         <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
          <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 id="modalHead">Time Table</h4><span class="glyphicon glyphicon-cog"></span>
        </div>
        <div class="modal-body" style="padding:20px 50px;">
            <form role="form"id='lecturesPerDayForm' method='post' action='config.php'>
            
                <div class='form-group'>
                    <label for='lecturesPerDay'>Lectures Per Day</label><input type='text' name='lecturesPerDay' id='lecturesPerDay' class='form-control' placeholder='numeric value'>
                    <label for='startTime'>Start Time</label><input type='text' name='startTime' id='startTime' class='form-control' placeholder='hh:mm'>
                    <label for='endTime'>End Time</label><input type='text' name='endTime' id='endTime' class='form-control' placeholder='hh:mm'>
                    <label for='breakAfter'>Break After</label><input type='text' name='breakAfter' id='breakAfter' class='form-control' placeholder='numeric value'>
                    <label for='breakDuration'>Break Duration</label><input type='text' name='breakDuration' id='breakDuration' class='form-control' placeholder='numeric'>
                    <label for='lecturesDuration'>Lectures Duration</label><input type='text' name='lecturesDuration' id='lecturesDuration' class='form-control' placeholder='50,40,40,40'>
                    <span id='lecturesDurationEntered'> 1,2...</span>
                    <input type='hidden' id='_configTimeTableSubmitted' name='_configTimeTableSubmitted'>
                
                </div>
				<div class="modal-footer">
          <p></p>
          <button type="submit" id="submitLecturesPerDay" class="btn btn-success center-block"><span class="glyphicon glyphicon-time"></span> Create Time Table</button>
          <p></p>
        </div>
                        
            </form>
                                          
        </div>
        
        </div>
      </div>
      
	    </div>
	<div>




        
    

                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
        
        
        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Copyright ©  All rights reserved</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        </div>  <!-- WRAPPER END -->



                        
 
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script>
            
    $(document).ready(function() {
        
        if($('#lecturesPerDay').val()===''){
            $('#lecturesPerDayModal').modal({ show: true});    
        }
        
        
        $('#submitLecturesPerDay').click(function () {
                              
            // ---- if value of lectures per day given, submit form-----
                        
            if ($('#lecturesPerDay').val()===''){
                alert('Value not given');
              
            }else{
              
              $('#_configTimeTableSubmitted').val('1');
              $('#lecturesPerDayForm').submit();
            }
            
        });
        
        $('#lecturesDuration').keyup(function () {
            var array = $(this).val().split(',');
                       
            sum = 0;
            
            array.forEach(function(num){
                
               sum+=parseInt(num); 
            });
            
           
            // ---- if value of lectures per day given, submit form-----
             $('#lecturesDurationEntered').html('Lectures: '+ array.length+', Time: '+sum+' minutes');        
            //alert($('#lecturesDuration').val());
            
        });
        
        $('#modal').modal({ show: false});
        
        var preCheckedArray=[]; //declare global array, so that it could remain alive till submission
        
        $("#modal").on("shown.bs.modal", function () {
            //prepare the list of already checked boxes
            $('.modalTable tr').each(function () {
               
                //processing each row, iterating through only checked boxes
                $(this).find('td input:checked').each(function () {

                    preCheckedArray.push($(this).val());
                
                });
                
            });
                                    
        });
        
        $("#modal").on("hidden.bs.modal", function () {
            //clear pre checked list
            preCheckedArray=[];
            //clear all check boxes
            $(':checkbox').each(function(){ 
                this.checked = false; 
            }); 
            
        });
                              
        
        $('#submitModalForm').click(function () {
                              
            // ---- get the list of checked checkboxes-----
            
            var postCheckedArray=[];
            $('.modalTable tr').each(function () {
               
                //processing each row, iterating through only checked boxes
                $(this).find('td input:checked').each(function () {

                    postCheckedArray.push($(this).val());
                
                });
                
            });
            
            var subjectIDs2Delete=$(preCheckedArray).not(postCheckedArray).get();
            var subjectIDs2Insert=$(postCheckedArray).not(preCheckedArray).get();
            
            //compare with start values of checkboxes, if no change in selection, dont update
            
            if (String(subjectIDs2Delete)==='' && String(subjectIDs2Insert)===''){
                alert('Nothing to update');
              
            }else{
              //memorize where selection changed and which rows should be affected ultimately
              $('#_subjectIDs2Insert').val(String(subjectIDs2Insert));
              $('#_subjectIDs2Delete').val(String(subjectIDs2Delete));
              
              $('form').submit();
            }
            
        });
        
        $('.glyphicon.glyphicon-pencil').click(function () {
                    
          alert($(this).closest('td').attr('id'));  
            
                    
        });
        
        $('.glyphicon.glyphicon-trash').click(function (event) {
            if (confirm("Record will be delted permanantly!\nAre you sure?")) {
                $('#_groupID').val(($(this).closest('tr').find('td:eq(0)').text()));
                $('#_opcode').val('delete');
                $('form').submit();

            }else{
                event.preventDefault();
            }

        });        
        
        $(".glyphicon-off").click(function () {
           $("#_signout").val('quit');
           $('form').submit();
        });
    
        $('.fixHeader').on('scroll', function() {
            $('thead', this).css('transform', 'translateY('+ this.scrollTop +'px)');
        });
    });
        </script>
        
        
    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/morrisjs/raphael-min.js"></script>
    <script src="js/morrisjs/morris.js"></script>
    <script src="js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="js/calendar/moment.min.js"></script>
    <script src="js/calendar/fullcalendar.min.js"></script>
    <script src="js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
    
    


</body>
</html>
<?php ob_end_flush(); ?>