<?php
ob_start();
session_start();
require_once 'dbconnect.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);

$row= '2';
$col='2';
$type='2';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>
    <link rel="stylesheet" href="styles.css" type="text/css" />
    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->

<style> 
.abc{
border: 1px  solid black ; 
border-collapse: collapse;
align : center;
}
td {
border: 1px  solid black ; 
border-collapse: collapse;
align : center;
}
</style>
</head>
<body class="size-1140">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>Add</strong>Subject</p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                    <li class="active-item"><a href="front.php">Home</a></li>

                    <li><a href="teacher.php" > Teachers </a> </li>
                    <li><a href="subject.php">Subject</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="ttview.php">Timetable View</a></li>
                    <li><a href="service.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    <button ><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></button>

</header>
<br><br><br><br><br><br><br><br><br><br>
<section>
   

        <div class="materialContainer">
            <div id="login-form">
                <div class="box">
                    <div class="col-md-12">
                        

                        <div class="form-group">
                            <hr />
                        </div>

                       

                        
<H1><FONT COLOR="DARKCYAN"><CENTER>SCHOOL TIME TABLE</FONT></H1>
<div  align="center">

	
	
	
	<?php
		echo "<table  class= 'abc'  width='80%'  height='200px'>";
		for($i=0;$i<7;$i++){
			echo "<tr class='alt' click='myFunction(this)' >";
			for($j=0;$j<10;$j++){
		
			echo"<td class='abc' height='100px' width='150px' click='myFunction(this)' >";
			if($i==$row && $j==$col && $type=='2'){
			echo"<div>";
			echo"<table >";
			echo"<tr ><td  height='50px' width='180px'>".$i."</td></tr> ";
			echo"<tr ><td  height='50px' width='180px'>".$j."</td></tr>";
			echo"</table>";
			echo"</div>";
			}
			else if ( $i==$row && $j==$col && $type=='3'){
			echo"<div>";
			echo"<table>";
			echo"<tr ><td class='abc' colspan='2' height='50px' width='160px'>".$i."</td></tr> ";
			echo"<tr><td class='abc' height='50px' width='80px'>".$j."</td> <td class='abc' height='50px' width='80px'>".$j."</td></tr>";
			echo"</table>";
			echo"</div>";
			}
			else if ( $i==$row && $j==$col && $type=='4'){
			
			echo"<div>";
			echo"<table >";
			echo"<tr ><td class='abc'  height='50px' width='60px'>".$i."</td><td class='abc'  height='50px' width='60px'>".$i."</td></tr> ";
			echo"<tr><td class='abc' height='50px' width='60px'>".$j."</td> <td class='abc' height='50px' width='60px'>".$j."</td></tr>";
			echo"</table>";
			echo"</div>";
			}
			if( $i=='0'&& $j=='0'){
			echo"<h2 align='center'> period/class </h2>";
			}
 if ($i=='0'&& $j=='1'){echo"<h>1st <br>8:30-9:30</h>";}
if ($i=='0'&& $j=='2') {echo"<h>2nd<br>9:30-10:30</h>";}
if ($i=='0'&& $j=='3'){echo "<h>3rd<br>10:3-11:30</h>";}
if ($i=='0'&& $j=='4'){echo "<h>4th<br>11:30-12:30</h>";}
if ($i=='0'&& $j=='5') {echo"<h>Break<br></h>";}
if ($i=='0'&& $j=='6') {echo"<h>5th<br>12:30-2:00</h>";}
if ($i=='0'&& $j=='7') {echo"<h>6th<br>2:00-3:00</h>";}
 if ($i=='0'&& $j=='8'){echo"<h>7th<br>3:00-4:00</h>";}
 if ($i=='0'&& $j=='9'){echo"<h>8th<br>4:00-5:00</h>";}

	
	
	if($i=='1'&& $j=='5'){
	echo" <h3 align= 'center'> L</h3>";
	}		
		if($i=='2'&& $j=='5'){
	echo" <h3 align= 'center'>U</h3>";
	}if($i=='3'&& $j=='5'){
	echo" <h3 align= 'center'>N</h3>";
	}if($i=='4'&& $j=='5'){
	echo" <h3 align= 'center'>C</h3>";
	}
	if($i=='5'&& $j=='5'){
	echo" <h3 align= 'center'>H</h3>";
	}
		
		
		
		
		if($i=='1'&& $j=='0'){
		echo" <h2 align='center'>10th</h2>" ; 
		}
		if($i=='2'&& $j=='0'){
		echo" <h2 align='center'>9th</h2>" ;
		}
		if($i=='3'&& $j=='0'){
		echo" <h2 align='center'>8th</h2>" ;
		}
		if($i=='4'&& $j=='0'){
		echo" <h2 align='center'>7th</h2>" ;
		}
		if($i=='5'&& $j=='0'){
		echo" <h2 align='center'>6th</h2>" ;
		}
		if($i=='6'&& $j=='0'){
		echo" <h1 align='center'>5th</h1>" ;
		}
		
		 
		
	        echo"</td>";
			}
			echo"</tr>";
		}
		
		
		echo"</table>";
	
	?>
	
	
</div>

<div id="id01" class="modal">
   <div class="modal-content animate" >
 
    <div class="imgcontainer">
      <span onClick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>

        <h2>select type of cell</h2>    
        
            <div class = "container"> 
			<div class="third">
<form method="post" >
<input width="50 px" type= 'text' name= 'type'>
<div class="en"> <h3 align="center"> 1</h3>
 <table cellpadding="15%"  border = "1px solid black" <a onClick="document.getElementById('id02').style.display='block'" style="width:auto;"></a> <tr ><td width="40px" <a href="table2.php" > </a></td></tr><tr><td width="40px"></td></tr></table> </div>
<div class="right"> <h3 align="center"> 2</h3> <table cellpadding="15%"  border = "1px solid black" <a onClick="document.getElementById('id08').style.display='block'" style="width:auto;"></a> <tr><td width="40px" colspan="2" ></td></tr><tr><td width="20px"></td><td width="20px"></td></tr></table></div>
<div class="end"> <h3 align="center"> 3</h3><table cellpadding="15%"  border = "1px solid black" <a onClick="document.getElementById('id09').style.display='block'" style="width:auto;"></a> <tr><td width="20px"></td><td width="20px"></tr><tr><td width="20px"></td><td width="20px"></td></tr></table></div>
<input type ="submit">
 </form>
</div>   
</div>
</div>
</div>

<script>
function myFunction() {
   
   $('td').click(function(){
    $("#ido1").show();
  var col = $(this).parent().children().index($(this));
  var row = $(this).parent().parent().children().index($(this).parent());
  alert('Row: ' + row + ', Column: ' + col);
});
	  
	  
}
</script>

                        
                        
                    </div>
                </div>

            </div>
        </div>

</section>

<!-- MAP -->
<div id="map-block">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1247814.3661917313!2d16.569872019090596!3d48.23131953825178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476c8cbf758ecb9f%3A0xddeb1d26bce5eccf!2sGallayova+2150%2F19%2C+841+02+D%C3%BAbravka!5e0!3m2!1ssk!2ssk!4v1440344568394" width="100%" height="200" frameborder="0" style="border:0"></iframe>
</div>
</section>
<!-- FOOTER -->
<footer>
    <div class="line">
        <div class="s-12 l-6">
            <p>All copyrights are reserved (2018)</p>
            <p> All images are for the need of project. Don't copy any image.</p>
        </div>
        <div class="s-12 l-6">
            <a class="right" href="http://www.iqrakhan/sites.com" title="Responsee - lightweight responsive framework">Design and coding<br> by Responsee Team</a>
        </div>
    </div>
</footer>
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>
<?php ob_end_flush(); ?>