<?php

session_start();

?>
<!DOCTYPE html>
<html>
	<head>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<title>Home</title>
		<?php include 'css/style.php' ?>
		<?php include 'links/links.php' ?>
	</head>
    <body>

<?php

include 'dbcon.php';

if (isset($_POST['submit'])){
	$username = mysqli_real_escape_string($con, $_POST['username']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$mobile =mysqli_real_escape_string($con, $_POST['mobile']);
	$batch = mysqli_real_escape_string($con, $_POST['batch']);
	$password =mysqli_real_escape_string($con, $_POST['password']);
	$cpassword =mysqli_real_escape_string($con, $_POST['cpassword']);

	$pass = password_hash($password, PASSWORD_BCRYPT);
	$cpass = password_hash($cpassword, PASSWORD_BCRYPT);

	$emailquery = "select * from registration where email = '$email' ";
	$query = mysqli_query($con,$emailquery);

	$emailcount = mysqli_num_rows($query);

	if ($emailcount>0) {
		?>
	 	  				<script>
	 	  					
	 	  					swal("Error!", "Email Already Exist!", "error");
	 	  				
	 	  				</script>	
    				<?php

		

	}else{
		if ($password === $cpassword) {
			 $insertquery = "insert into registration( username, email, mobile,batch, password, cpassword) values('
			 $username','$email','$mobile,'$batch'
			 ','$pass','$cpass')";
			 $iquery = mysqli_query($con, $insertquery);

			 if($iquery) {
					?>
	 	  				<script>
	 	  					
	 	  					swal("Registered!", "You registered successfully!", "success");
	 	  				
	 	  				</script>	
    				<?php
				}else{

					?>
	 	  				<script>
	 	  					swal("Error!", "Not Inserted!", "error");
	 	  				</script>	
    				<?php
}
			
		}else {
			?>
	 	  		<script>
	 	  			swal("Error!", "Passwords are not Matching!", "error");
	 	  				</script>	
    				<?php
		}
	}
} 
	


?>    	
			<h4 class="card-title mt-3 text-center" style="font-size: 30px "></h4>
			<style>
			body {
			  background-image: url('background.png');
			  background-repeat: no-repeat;
			  background-size: 100% 4555%;

			}
			</style>
		<div class="Signupbox2">
		<img src="teacher.png" class="teacher">
			<h1 class="h1" style="font-size: 20px">Sign Up Here</h1>	
			
			<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST">
				<div class="form-group input-group">
					<div class="input-group-prepend">
						<span class="input-group-text"> <i class="fa fa-user"></i></span>
					</div>
					<input name="username" class="form-control" placeholder="Full Name" type="text" required >
					</div><!--form group-->
					<div class="form-group input-group">
						<div class="input-group-prepend">
							<span class="input-group-text"> <i class="fa fa-envelope"></i></span>
						</div>
						<input name="email" class="form-control" placeholder="Email Address" type="email" required>
						</div><!--form group-->
						<div class="form-group input-group">
							<div class="input-group-prepend">
								<span class="input-group-text"> <i class="fa fa-phone"></i></span>
							</div>
							<input name="mobile" class="form-control" placeholder="Phone Number" type="number" required>
							<div class="form-group input-group">
								<div class="input-group-prepend">
									<span class="input-group-text"> <i class="fa fa-book"></i></span>
								</div>
								<input name="batch" class="form-control" placeholder="Enter your Batch" type="batch" required> 
								</div><!--form group-->

								<div class="form-group input-group">
									<div class="input-group-prepend">
										<span class="input-group-text"> <i class="fa fa-lock"></i></span>
									</div>
									<input class="form-control" placeholder="Create Password" type="password" name="password" value="" required>
									</div><!--form group-->
									<div class="form-group input-group">
										<div class="input-group-prepend">
											<span class="input-group-text"> <i class="fa fa-lock"></i></span>
										</div>
										<input  class="form-control" placeholder="Confirm password" type="password" name="cpassword" required>
										</div><!--form group-->
									<div class="form-group">
										<button type="submit" name="submit" class="btn btn-primary btn-block"> Create account</button>
										</div><!--form group-->
										<p class="text-center">Have an account? <a href="login.php">Log In</a></p> 
									</form>

								</article>	
								</div> <!--card.// -->
							</div>
							
						</div>
					</div>	
		</div>
			</body>
		</html>