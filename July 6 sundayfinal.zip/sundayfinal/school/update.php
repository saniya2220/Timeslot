
<?php
ob_start();
session_start();
require_once 'dbconnect.php';

// if session is not set this will redirect to login page
if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
}
// select loggedin users detail
$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userEmail']; ?></title>

    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="css/components.css">

    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->

</head>
<body class="size-1140">
<!-- TOP NAV WITH LOGO -->
<header>
    <div id="topbar">
        <div class="line">
            <div class="s-12 m-6 l-6">
                <p>CONTACT US: <strong>0300-1234567</strong> | <strong>superiorcollege@gmail.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>Add</strong>Subject</p>
            </div>
            <div class="top-nav s-12 l-10">
                <p class="nav-text">Custom menu text</p>
                <ul class="right">
                 

                    <li><a href="teacher.php" > Teachers </a> </li>
                    <li><a href="subject.php">Subject</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="ttview.php">Timetable View</a></li>
                    <li><a href="service.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>

            </div>
        </div>
    </nav>
    <button ><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></button>

</header>
<br><br><br><br><br><br><br><br><br><br>


<section>
    <form class="modal-content animate" method="post" >

        <div class="materialContainer">
            <div id="login-form">
                <div class="box">
                    <div class="col-md-12">
                        <div class="title">Update  Subject </div>

                        <div class="form-group">
                            <hr />
                        </div>

                      


                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                                <input type="text" name="subname" class="form-control" value="<?php echo $sub1;?>" maxlength="15" />
                            </div>
                        </div>
						
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                                <input type="text" name="class" class="form-control"  value="<?php echo $class1;?>" maxlength="15" />
                            </div>
                        </div>
						
						 <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                               
                            </div>
							</div>
							

                        <div class="form-group">
                            <hr />
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary" name="btn-login">Submit</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>

</section>

<!-- MAP -->
<div id="map-block">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1247814.3661917313!2d16.569872019090596!3d48.23131953825178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476c8cbf758ecb9f%3A0xddeb1d26bce5eccf!2sGallayova+2150%2F19%2C+841+02+D%C3%BAbravka!5e0!3m2!1ssk!2ssk!4v1440344568394" width="100%" height="200" frameborder="0" style="border:0"></iframe>
</div>
</section>
<!-- FOOTER -->
<footer>
    <div class="line">
        <div class="s-12 l-6">
            <p>All copyrights are reserved (2018)</p>
            <p> All images are for the need of project. Don't copy any image.</p>
        </div>
        <div class="s-12 l-6">
            <a class="right" href="http://www.iqrakhan/sites.com" title="Responsee - lightweight responsive framework">Design and coding<br> by Responsee Team</a>
        </div>
    </div>
</footer>
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>

<?php 

$id = $_GET['id'];
$SelSql = "SELECT * FROM `subject` WHERE id = $id";
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'interactivetimetable');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
$id = $_GET['id'];
$SelSql = "SELECT * FROM `subject` WHERE id = $id";
$res = mysqli_query($connection, $SelSql);
$r = mysqli_fetch_assoc($res);
$sub1=$r['sname'];
	$class1=$r['class'];
	
	
if(isset($_POST)& !empty($_POST)){
$sub=$_POST['subname'];
$class=$_POST['class'];


$UpdateSql = "UPDATE `subject` SET sname='$sub',class='$class',subteacher='$subt'
  WHERE  sid=$id";
	$res = mysqli_query($connection, $UpdateSql);
	if($res){
		header('location: suboutput.php');
	}else{
		echo "Failed to update data.";
	}
}
?>
